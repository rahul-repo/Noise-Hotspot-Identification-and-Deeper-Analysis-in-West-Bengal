#Library and data upload
main_folder <- "C:/Users/rahul/OneDrive/Desktop/BStat_2023-26/Stat Project/Stat Comprehensive/Group project/Noise data/noise data"
library(readr)
library(dplyr)
library(purrr)
library(stringr)

#Data Preparation
files <- list.files(
  path = main_folder,
  pattern = "\\.csv$",
  recursive = TRUE,
  full.names = TRUE
)
read_noise_file <- function(file_path){
  
  # Read CSV
  df <- read_csv(file_path, show_col_types = FALSE)
  
  # District name = parent folder name
  district <- basename(dirname(file_path))
  
  # Station name = filename without extension
  station <- tools::file_path_sans_ext(basename(file_path))
  
  # Add columns
  df$District <- district
  df$Station <- station
  
  return(df)
}
noise_data <- map_dfr(files, read_noise_file)
dim(noise_data)

head(noise_data)

names(noise_data)
install.packages("lubridate")

library(lubridate)
noise_data <- noise_data %>%
  mutate(
    Date = as.Date(timestamp),
    Year = year(timestamp),
    Month = month(timestamp),
    MonthName = month(timestamp, label = TRUE),
    Day = day(timestamp),
    Hour = hour(timestamp),
    Minute = minute(timestamp),
    Weekday = wday(timestamp, label = TRUE),
    DayOfYear = yday(timestamp)
  )
hourly_data <- noise_data %>%
  group_by(
    District,
    Station,
    Date,
    Year,
    Month,
    MonthName,
    Weekday,
    DayOfYear,
    Hour
  ) %>%
  summarise(
    mean_laeqt = mean(laeqt),
    mean_lceqt = mean(lceqt),
    mean_lzeqt = mean(lzeqt),
    mean_lapeakt = mean(lapeakt),
    
    max_lapeakt = max(lapeakt),
    
    n_obs = n(),
    
    .groups = "drop"
  )

daily_cycles <- hourly_data %>%
  select(
    District,
    Station,
    Date,
    Hour,
    mean_laeqt
  ) %>%
  pivot_wider(
    names_from = Hour,
    values_from = mean_laeqt
  )
daily_cycles_complete <- daily_cycles %>%
  filter(complete.cases(.))

# FPCA

curve_matrix <- daily_cycles_complete %>%
  select(all_of(as.character(0:23)))

curve_row_scaled <- t(
  apply(curve_matrix, 1, scale)
)

set.seed(123)

sample_index <- sample(
  1:nrow(curve_row_scaled),
  10000
)

curve_sample <- curve_row_scaled[sample_index, ]

pca_result <- prcomp(
  curve_sample,
  center = FALSE,
  scale. = FALSE
)

summary(pca_result)

# Plotting of first 3PCA

pc_df <- data.frame(
  Hour = 0:23,
  PC1 = pca_result$rotation[,1],
  PC2 = pca_result$rotation[,2],
  PC3 = pca_result$rotation[,3]
)

library(tidyr)

pc_long <- pc_df %>%
  pivot_longer(
    cols = -Hour,
    names_to = "PC",
    values_to = "Loading"
  )

library(ggplot2)

ggplot(
  pc_long,
  aes(
    x = Hour,
    y = Loading,
    color = PC
  )
) +
  geom_line(linewidth = 1.2) +
  labs(
    title = "First Three Functional Principal Components",
    y = "Component Loading"
  )
