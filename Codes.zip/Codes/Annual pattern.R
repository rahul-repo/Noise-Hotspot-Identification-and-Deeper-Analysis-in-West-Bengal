#Library and data upload
main_folder <- "C:/Users/rahul/OneDrive/Desktop/BStat_2023-26/Stat Project/Stat Comprehensive/Group project/Noise data/noise data"
library(readr)
library(dplyr)
library(purrr)
library(stringr)

#Data Preparation
files <- list.files(
  path = main_folder,
  pattern = "\\.csv$",
  recursive = TRUE,
  full.names = TRUE
)
read_noise_file <- function(file_path){
  
  # Read CSV
  df <- read_csv(file_path, show_col_types = FALSE)
  
  # District name = parent folder name
  district <- basename(dirname(file_path))
  
  # Station name = filename without extension
  station <- tools::file_path_sans_ext(basename(file_path))
  
  # Add columns
  df$District <- district
  df$Station <- station
  
  return(df)
}
noise_data <- map_dfr(files, read_noise_file)
dim(noise_data)

head(noise_data)

names(noise_data)
install.packages("lubridate")

library(lubridate)
noise_data <- noise_data %>%
  mutate(
    Date = as.Date(timestamp),
    Year = year(timestamp),
    Month = month(timestamp),
    MonthName = month(timestamp, label = TRUE),
    Day = day(timestamp),
    Hour = hour(timestamp),
    Minute = minute(timestamp),
    Weekday = wday(timestamp, label = TRUE),
    DayOfYear = yday(timestamp)
  )
hourly_data <- noise_data %>%
  group_by(
    District,
    Station,
    Date,
    Year,
    Month,
    MonthName,
    Weekday,
    DayOfYear,
    Hour
  ) %>%
  summarise(
    mean_laeqt = mean(laeqt),
    mean_lceqt = mean(lceqt),
    mean_lzeqt = mean(lzeqt),
    mean_lapeakt = mean(lapeakt),
    
    max_lapeakt = max(lapeakt),
    
    n_obs = n(),
    
    .groups = "drop"
  )

#Annual Pattern
daily_summary <- hourly_data %>%
  group_by(
    District,
    Station,
    Date,
    Year,
    Month,
    DayOfYear
  ) %>%
  summarise(
    daily_laeqt = mean(mean_laeqt),
    .groups = "drop"
  )
annual_pattern <- daily_summary %>%
  group_by(DayOfYear) %>%
  summarise(
    mean_laeqt = mean(daily_laeqt),
    .groups = "drop"
  )
library(ggplot2)

ggplot(
  annual_pattern,
  aes(
    x = DayOfYear,
    y = mean_laeqt
  )
) +
  geom_line(linewidth = 1) +
  labs(
    title = "Estimated Annual Noise Pattern",
    x = "Day of Year",
    y = "Average Daily LAeq,T"
  )

#LOESS smoothing
ggplot(
  annual_pattern,
  aes(
    x = DayOfYear,
    y = mean_laeqt
  )
) +
  geom_line(alpha = 0.4) +
  geom_smooth(
    method = "loess",
    span = 0.15,
    linewidth = 1.2,
    se = FALSE
  ) +
  labs(
    title = "Smoothed Annual Noise Pattern",
    x = "Day of Year",
    y = "Average Daily LAeq,T"
  )
