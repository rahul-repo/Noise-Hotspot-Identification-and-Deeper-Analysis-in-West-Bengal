#Library and data upload
main_folder <- "C:/Users/rahul/OneDrive/Desktop/BStat_2023-26/Stat Project/Stat Comprehensive/Group project/Noise data/noise data"
library(readr)
library(dplyr)
library(purrr)
library(stringr)

#Data Preparation
files <- list.files(
  path = main_folder,
  pattern = "\\.csv$",
  recursive = TRUE,
  full.names = TRUE
)
read_noise_file <- function(file_path){
  
  # Read CSV
  df <- read_csv(file_path, show_col_types = FALSE)
  
  # District name = parent folder name
  district <- basename(dirname(file_path))
  
  # Station name = filename without extension
  station <- tools::file_path_sans_ext(basename(file_path))
  
  # Add columns
  df$District <- district
  df$Station <- station
  
  return(df)
}
noise_data <- map_dfr(files, read_noise_file)
dim(noise_data)

head(noise_data)

names(noise_data)
install.packages("lubridate")

library(lubridate)
noise_data <- noise_data %>%
  mutate(
    Date = as.Date(timestamp),
    Year = year(timestamp),
    Month = month(timestamp),
    MonthName = month(timestamp, label = TRUE),
    Day = day(timestamp),
    Hour = hour(timestamp),
    Minute = minute(timestamp),
    Weekday = wday(timestamp, label = TRUE),
    DayOfYear = yday(timestamp)
  )
hourly_data <- noise_data %>%
  group_by(
    District,
    Station,
    Date,
    Year,
    Month,
    MonthName,
    Weekday,
    DayOfYear,
    Hour
  ) %>%
  summarise(
    mean_laeqt = mean(laeqt),
    mean_lceqt = mean(lceqt),
    mean_lzeqt = mean(lzeqt),
    mean_lapeakt = mean(lapeakt),
    
    max_lapeakt = max(lapeakt),
    
    n_obs = n(),
    
    .groups = "drop"
  )

#Diurnal
diurnal_pattern <- hourly_data %>%
  group_by(Hour) %>%
  summarise(
    mean_laeqt = mean(mean_laeqt),
    mean_lceqt = mean(mean_lceqt),
    mean_lzeqt = mean(mean_lzeqt),
    mean_lapeakt = mean(mean_lapeakt)
  )


# District wise
district_diurnal <- hourly_data %>%
  group_by(District, Hour) %>%
  summarise(
    mean_laeqt = mean(mean_laeqt),
    .groups = "drop"
  )

# Clustering

daily_cycles <- hourly_data %>%
  select(
    District,
    Station,
    Date,
    Hour,
    mean_laeqt
  ) %>%
  pivot_wider(
    names_from = Hour,
    values_from = mean_laeqt
  )

daily_cycles_complete <- daily_cycles %>%
  filter(complete.cases(.))

dim(daily_cycles_complete)

curve_matrix <- daily_cycles_complete %>%
  select(`0`:`23`)

curve_scaled <- scale(curve_matrix)

# Determine number of clusters:Elbow method

set.seed(123)

sample_index <- sample(
  1:nrow(curve_scaled),
  10000
)

curve_sample <- curve_scaled[sample_index, ]

wss <- numeric(10)

for(k in 1:10){
  
  kfit <- kmeans(
    curve_sample,
    centers = k,
    nstart = 20
  )
  
  wss[k] <- kfit$tot.withinss
}
plot(
  1:10,
  wss,
  type = "b",
  pch = 19,
  xlab = "Number of Clusters",
  ylab = "Within-cluster Sum of Squares",
  main = "Elbow Plot"
)

# Final Clustering
curve_matrix <- daily_cycles_complete %>%
  select(all_of(as.character(0:23)))

curve_row_scaled <- t(
  apply(curve_matrix, 1, scale)
)

set.seed(123)

sample_index <- sample(
  1:nrow(curve_row_scaled),
  10000
)

curve_sample <- curve_row_scaled[sample_index, ]

final_kmeans <- kmeans(
  curve_sample,
  centers = 4,
  nstart = 50,
  iter.max = 100
)

cluster_centers <- as.data.frame(
  t(final_kmeans$centers)
)

cluster_centers$Hour <- 0:23

library(tidyr)

cluster_centers_long <- cluster_centers %>%
  pivot_longer(
    cols = -Hour,
    names_to = "Cluster",
    values_to = "Scaled_LAeq"
  )

library(ggplot2)

ggplot(
  cluster_centers_long,
  aes(
    x = Hour,
    y = Scaled_LAeq,
    color = Cluster
  )
) +
  geom_line(linewidth = 1.5) +
  labs(
    title = "Representative Daily Noise Shapes",
    x = "Hour of Day",
    y = "Normalized Noise Level"
  )