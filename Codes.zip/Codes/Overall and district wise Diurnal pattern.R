#Library and data upload
main_folder <- "C:/Users/rahul/OneDrive/Desktop/BStat_2023-26/Stat Project/Stat Comprehensive/Group project/Noise data/noise data"
library(readr)
library(dplyr)
library(purrr)
library(stringr)

#Data Preparation
files <- list.files(
  path = main_folder,
  pattern = "\\.csv$",
  recursive = TRUE,
  full.names = TRUE
)
read_noise_file <- function(file_path){
  
  # Read CSV
  df <- read_csv(file_path, show_col_types = FALSE)
  
  # District name = parent folder name
  district <- basename(dirname(file_path))
  
  # Station name = filename without extension
  station <- tools::file_path_sans_ext(basename(file_path))
  
  # Add columns
  df$District <- district
  df$Station <- station
  
  return(df)
}
noise_data <- map_dfr(files, read_noise_file)
dim(noise_data)

head(noise_data)

names(noise_data)
install.packages("lubridate")

library(lubridate)
noise_data <- noise_data %>%
  mutate(
    Date = as.Date(timestamp),
    Year = year(timestamp),
    Month = month(timestamp),
    MonthName = month(timestamp, label = TRUE),
    Day = day(timestamp),
    Hour = hour(timestamp),
    Minute = minute(timestamp),
    Weekday = wday(timestamp, label = TRUE),
    DayOfYear = yday(timestamp)
  )
hourly_data <- noise_data %>%
  group_by(
    District,
    Station,
    Date,
    Year,
    Month,
    MonthName,
    Weekday,
    DayOfYear,
    Hour
  ) %>%
  summarise(
    mean_laeqt = mean(laeqt),
    mean_lceqt = mean(lceqt),
    mean_lzeqt = mean(lzeqt),
    mean_lapeakt = mean(lapeakt),
    
    max_lapeakt = max(lapeakt),
    
    n_obs = n(),
    
    .groups = "drop"
  )

#Diurnal
diurnal_pattern <- hourly_data %>%
  group_by(Hour) %>%
  summarise(
    mean_laeqt = mean(mean_laeqt),
    mean_lceqt = mean(mean_lceqt),
    mean_lzeqt = mean(mean_lzeqt),
    mean_lapeakt = mean(mean_lapeakt)
  )
plot(
  diurnal_pattern$Hour,
  diurnal_pattern$mean_laeqt,
  type = "l",
  lwd = 3,
  xlab = "Hour of Day",
  ylab = "Mean LAeq,T",
  main = "Mean Diurnal Noise Pattern"
)
plot(
  diurnal_pattern$Hour,
  diurnal_pattern$mean_laeqt,
  type = "l",
  lwd = 3,
  ylim = range(
    c(
      diurnal_pattern$mean_laeqt,
      diurnal_pattern$mean_lceqt,
      diurnal_pattern$mean_lzeqt
    )
  ),
  xlab = "Hour",
  ylab = "Noise Level",
  main = "Diurnal Noise Profiles"
)

lines(diurnal_pattern$Hour,
      diurnal_pattern$mean_lceqt,
      lwd = 2,
      lty = 2)

lines(diurnal_pattern$Hour,
      diurnal_pattern$mean_lzeqt,
      lwd = 2,
      lty = 3)

legend(
  "topright",
  legend = c("LAeq,T","LCeq,T","LZeq,T"),
  lty = c(1,2,3),
  lwd = c(3,2,2)
)


# District wise
district_diurnal <- hourly_data %>%
  group_by(District, Hour) %>%
  summarise(
    mean_laeqt = mean(mean_laeqt),
    .groups = "drop"
  )
library(ggplot2)

ggplot(district_diurnal,
       aes(x = Hour,
           y = mean_laeqt,
           color = District,
           group = District)) +
  geom_line(linewidth = 1) +
  labs(
    title = "District-wise Diurnal Noise Patterns",
    x = "Hour of Day",
    y = "Mean LAeq,T"
  )

